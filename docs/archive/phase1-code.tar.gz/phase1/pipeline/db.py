"""Explicit versioned migrations and short transactions."""
import hashlib
import os
from pathlib import Path

import psycopg
from psycopg.rows import dict_row

ROOT = Path(__file__).resolve().parents[2]


def connect():
    if os.environ.get("DATABASE_URL"):
        return psycopg.connect(os.environ["DATABASE_URL"], autocommit=True, row_factory=dict_row)
    return psycopg.connect(host=os.getenv("POSTGRES_HOST", "localhost"),
                          port=os.getenv("POSTGRES_PORT", "5432"),
                          dbname=os.environ["POSTGRES_DB"], user=os.environ["POSTGRES_USER"],
                          password=os.environ["POSTGRES_PASSWORD"],
                          connect_timeout=10, autocommit=True, row_factory=dict_row)


def migrate(conn):
    with conn.transaction():
        conn.execute("SELECT pg_advisory_xact_lock(91342001)")
        conn.execute("""CREATE TABLE IF NOT EXISTS schema_migration (
            name TEXT PRIMARY KEY, sha256 TEXT NOT NULL,
            applied_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
        paths = [ROOT / "data/initialization.sql", *sorted((ROOT / "data/migrations").glob("*.sql"))]
        for path in paths:
            source = path.read_text(encoding="utf-8")
            checksum = hashlib.sha256(source.encode()).hexdigest()
            previous = conn.execute("SELECT sha256 FROM schema_migration WHERE name=%s", (path.name,)).fetchone()
            if previous:
                if previous["sha256"] != checksum:
                    raise ValueError(f"Applied migration changed: {path.name}. Add a new migration instead.")
                continue
            # The original initializer wraps itself in BEGIN/COMMIT. The migration
            # runner owns the transaction so its ledger commits atomically too.
            source = "\n".join(line for line in source.splitlines() if line.strip() not in {"BEGIN;", "COMMIT;"})
            conn.execute(source)
            conn.execute("INSERT INTO schema_migration(name,sha256) VALUES (%s,%s)", (path.name, checksum))
