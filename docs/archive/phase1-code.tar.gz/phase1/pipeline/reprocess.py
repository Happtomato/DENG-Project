"""Reparse legacy MediaMarkt evidence without claiming a new observation."""
import hashlib
import importlib.util
import json
from pathlib import Path

from .db import ROOT
from .contracts import digest, timestamp
from .digitec import atomic_raw


def reprocess_mediamarkt(raw_dir=None, output_dir=None):
    raw_dir = Path(raw_dir or ROOT / 'data/raw/mediamarkt')
    output_dir = Path(output_dir or raw_dir / 'reprocessed')
    spec = importlib.util.spec_from_file_location('mm_reprocess', ROOT / 'backend/scrapeMediamarkt/pipeline.py')
    pipeline = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pipeline)
    config = json.loads((ROOT / 'backend/scrapeMediamarkt/scope.json').read_text())
    report = {'written': 0, 'existing': 0, 'unresolved': []}
    for path in sorted(raw_dir.glob('*.json')):
        try:
            original_bytes = path.read_bytes()
            original = json.loads(original_bytes)
            metadata = original['metadata']
            if metadata.get('parser_version'):
                continue
            if metadata.get('source') != 'mediamarkt' or metadata.get('access_method') != 'public_html':
                raise ValueError('Legacy acquisition is not a documented public HTML observation')
            observed = timestamp(metadata['collected_at'])
            sku = metadata['source_product_id']
            # Only existing evidence; never fetch a replacement page from the network.
            candidates = sorted((ROOT / 'data/debug/mediamarkt').glob(str(sku) + '_*.html'))
            single = ROOT / 'data/debug/mediamarkt_product.html'
            if single.exists():
                candidates.append(single)
            match = None
            for candidate in candidates:
                html = candidate.read_bytes().decode('utf-8')
                try:
                    parsed = pipeline.mm.parse_html(html, metadata['source_url'], 'public_html')
                except pipeline.mm.ScraperError:
                    continue
                if parsed['raw_payload'] == original.get('raw_payload'):
                    match = parsed
                    break
            if match is None:
                raise ValueError('No saved HTML with the identical original Product payload')
            category = match['metadata'].get('category_code')
            if category not in config:
                raise ValueError('Category not confirmed')
            status, reason = pipeline.scope_decision(match, category, config[category])
            # Parsing old HTML today must never create today's price observation.
            match['metadata'].update(collected_at=observed.isoformat(), scope_status=status, scope_reason=reason,
                                     reprocessed=True, observation_day=pipeline.day(observed.isoformat()))
            match['price_history']['collected_at'] = observed.isoformat()
            match['provenance'].update(parent_raw_sha256=hashlib.sha256(original_bytes).hexdigest(),
                                        reprocessing_method='identical_saved_product_payload')
            result = atomic_raw(output_dir / (digest(match) + '.json'), match)
            report['written' if result else 'existing'] += 1
        except (OSError, ValueError, TypeError, KeyError) as error:
            report['unresolved'].append({'file': path.name, 'reason': str(error)})
    return report
