"""Import authorized, mapped Digitec exports. No HTTP client or hidden API."""
import hashlib
import json
import os
import tempfile
from pathlib import Path
from urllib.parse import urlsplit

from .contracts import DETAIL_FIELDS, PRODUCT_FIELDS, VERSION, ReviewRequired, digest, validate


def atomic_raw(path, record):
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = json.dumps(record, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent, suffix=".tmp", delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(encoded)
        handle.flush()
        os.fsync(handle.fileno())
    try:
        # Publish complete bytes atomically, without overwriting existing evidence.
        os.link(temporary, path)
        return True
    except FileExistsError:
        if path.read_text(encoding="utf-8") != encoded:
            raise ReviewRequired("Conflicting immutable raw observation")
        return False
    finally:
        temporary.unlink(missing_ok=True)


def map_export(item, permission_reference, document_text):
    """The exchange contract is documented; new upstream formats need a mapper."""
    if not isinstance(item, dict):
        raise ReviewRequired("Export item must be an object")
    if item.get("is_example") or item.get("is_test"):
        raise ReviewRequired("Examples cannot be imported")
    url = item.get("source_url", "")
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.hostname not in {"www.digitec.ch", "digitec.ch"}:
        raise ReviewRequired("Export must identify its Digitec product URL")
    category = item.get("category_code")
    if category not in DETAIL_FIELDS:
        raise ReviewRequired("Export category must be gpu/ram/ssd")
    product = {field: (item.get("product") or {}).get(field) for field in PRODUCT_FIELDS}
    sku = str(item.get("source_product_id") or "")
    record = {
        "metadata": {
            "schema_version": 1, "parser_version": "digitec-export-" + VERSION,
            "source": "digitec", "source_type": "retailer", "source_product_id": sku,
            "source_url": url, "collected_at": item.get("collected_at"),
            "access_method": "authorized_export", "category_code": category,
            "scope_status": item.get("scope_status"), "quality_warnings": item.get("quality_warnings", []),
            "observation_type": item.get("observation_type", "master_data"),
            "observation_id": item.get("observation_id"), "provider": item.get("provider", "digitec"),
            "source_series_id": item.get("source_series_id"),
            "source_observation_id": item.get("source_observation_id"),
        },
        "brand": {"name": item.get("brand")}, "category": {"name": category.upper()},
        "retailer": {"name": "Digitec", "website": "https://www.digitec.ch"},
        "product": product,
        "retailer_product": {"retailer_sku": sku, "retailer_product_name": product["product_name"], "product_url": url},
        "price_history": item.get("price_history") or {}, "seller": item.get("seller"),
        "raw_payload": item,
        "source_document": {"sha256": hashlib.sha256(document_text.encode()).hexdigest(), "content_utf8": document_text},
        "provenance": {"permission_reference": permission_reference, "provider": item.get("provider", "digitec"),
                       "mapping_version": "digitec-export-" + VERSION},
    }
    for code, fields in DETAIL_FIELDS.items():
        record[code + "_details"] = {field: (item.get(code + "_details") or {}).get(field) for field in fields}
    validate(record, "digitec")
    return record


def import_exports(input_path, output_dir, permission_reference=None):
    input_path, output_dir = Path(input_path), Path(output_dir)
    files = sorted(input_path.glob("*.json")) if input_path.is_dir() else ([input_path] if input_path.is_file() else [])
    if not files:
        return {"source": "digitec", "status": "awaiting_source_data", "written": 0, "existing": 0, "errors": []}
    if not permission_reference:
        raise ReviewRequired("Set DIGITEC_PERMISSION_REFERENCE or pass --permission-reference after authorization")
    report = {"source": "digitec", "status": "processed", "written": 0, "existing": 0, "errors": []}
    for path in files:
        try:
            document = path.read_bytes().decode("utf-8")
            data = json.loads(document)
            items = data if isinstance(data, list) else [data]
        except (OSError, ValueError) as error:
            report["errors"].append({"file": path.name, "error": str(error)})
            continue
        for index, item in enumerate(items):
            try:
                record = map_export(item, permission_reference, document)
                report["written" if atomic_raw(output_dir / (digest(record) + ".json"), record) else "existing"] += 1
            except (OSError, ValueError, TypeError, KeyError) as error:
                report["errors"].append({"file": path.name, "record": index, "error": str(error)})
    return report
