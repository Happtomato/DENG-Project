"""Independent raw-file import, matching and PostgreSQL ingestion."""
