"""Batch commands shared by containers, Prefect and local execution."""
import argparse
import json
import os
from pathlib import Path

from .db import ROOT, connect, migrate
from .digitec import import_exports
from .ingest import ingest_directory
from .reprocess import reprocess_mediamarkt


def verification(conn):
    tables = ("product", "retailer_product", "price_history", "product_gtin", "matching_review")
    counts = {table: conn.execute(f"SELECT count(*) AS n FROM {table}").fetchone()["n"] for table in tables}
    counts["digitec_validated_products"] = conn.execute("SELECT count(*) AS n FROM product WHERE master_status='digitec_validated'").fetchone()["n"]
    counts["comparable_product_days"] = conn.execute("SELECT count(*) AS n FROM digitec_mediamarkt_comparison").fetchone()["n"]
    counts["invalid_prices"] = conn.execute("SELECT count(*) AS n FROM price_history WHERE price_chf IS NULL OR price_chf<=0").fetchone()["n"]
    counts["duplicate_observations"] = conn.execute("""SELECT count(*) AS n FROM (
        SELECT observation_key FROM price_history WHERE observation_key IS NOT NULL
        GROUP BY observation_key HAVING count(*)>1) d""").fetchone()["n"]
    sources = conn.execute("SELECT retailer_code,status,count(*) AS records FROM raw_record GROUP BY retailer_code,status ORDER BY 1,2").fetchall()
    return {"counts": counts, "raw_status": sources,
            "digitec_status": "available" if counts["digitec_validated_products"] else "awaiting_authorized_data",
            "comparison_status": "available" if counts["comparable_product_days"] else "awaiting_two_verified_retailer_observations_on_same_day"}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("migrate")
    sub.add_parser("verify")
    sub.add_parser("reprocess-mediamarkt")
    ingest = sub.add_parser("ingest")
    ingest.add_argument("retailer", choices=["digitec", "mediamarkt"])
    ingest.add_argument("--input", type=Path)
    imports = sub.add_parser("import-digitec")
    imports.add_argument("--input", type=Path, default=ROOT / "data/import/digitec")
    imports.add_argument("--output", type=Path, default=ROOT / "data/raw/digitec")
    imports.add_argument("--permission-reference", default=os.getenv("DIGITEC_PERMISSION_REFERENCE"))
    args = parser.parse_args(argv)
    try:
        if args.command == "reprocess-mediamarkt":
            result = reprocess_mediamarkt()
        elif args.command == "import-digitec":
            result = import_exports(args.input, args.output, args.permission_reference)
        else:
            with connect() as conn:
                if args.command == "migrate":
                    migrate(conn)
                    result = {"migration": "complete"}
                elif args.command == "verify":
                    result = verification(conn)
                else:
                    result = ingest_directory(conn, args.input or ROOT / "data/raw" / args.retailer, args.retailer)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
        if args.command == "verify":
            return int(result["counts"]["invalid_prices"] > 0 or result["counts"]["duplicate_observations"] > 0)
        return int(bool(result.get("error") or result.get("errors")))
    except Exception as error:
        print(json.dumps({"status": "failed", "type": type(error).__name__, "message": str(error).splitlines()[0]}))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
