"""Source-independent validation. Unknown facts are never inferred from a model family."""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

VERSION = "1.0"
CATEGORIES = {"gpu", "ram", "ssd"}
PRODUCT_FIELDS = ("product_name", "ean", "mpn", "release_date", "model", "series",
                  "generation", "msrp_chf", "manufacturer_url")
DETAIL_FIELDS = {
    "gpu": ("gpu_model", "gpu_architecture", "vram_gb", "vram_type", "clock_mhz",
            "boost_clock_mhz", "pcie_interface", "tdp_watts", "cooling_variant"),
    "ram": ("ram_type", "total_capacity_gb", "module_count", "capacity_per_module_gb",
            "speed_mts", "cas_latency", "voltage", "ecc", "rgb"),
    "ssd": ("capacity_gb", "interface", "pcie_generation", "form_factor", "nand_type",
            "controller", "read_speed_mbps", "write_speed_mbps", "tbw", "dram_cache"),
}
# A disagreement in any known variant-defining attribute prevents an automatic match.
VARIANT_FIELDS = {
    "gpu": ("gpu_model", "vram_gb", "vram_type", "cooling_variant"),
    "ram": ("ram_type", "total_capacity_gb", "module_count", "capacity_per_module_gb",
            "speed_mts", "cas_latency", "ecc", "rgb"),
    "ssd": ("capacity_gb", "interface", "pcie_generation", "form_factor", "dram_cache"),
}


class ReviewRequired(ValueError):
    """Record stays in the raw layer/review queue, never silently merged."""


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def text(value):
    return str(value).strip() if value is not None and str(value).strip() else None


def normalized(value):
    return unicodedata.normalize("NFKC", text(value) or "").casefold().strip()


def mpn_key(value):
    # Keep punctuation and suffixes: removing them can collapse real variants.
    return unicodedata.normalize("NFKC", text(value) or "").upper().strip() or None


def gtin(value):
    if value is None or value == "":
        return None
    if not isinstance(value, str) or not re.fullmatch(r"[0-9]{8}|[0-9]{12,14}", value):
        raise ReviewRequired("GTIN must be an 8/12/13/14 digit string; preserve leading zeros")
    total = sum(int(c) * (3 if i % 2 == 0 else 1) for i, c in enumerate(reversed(value[:-1])))
    if (total + int(value[-1])) % 10 or set(value) == {"0"}:
        raise ReviewRequired("Invalid GTIN check digit")
    return value.zfill(14)


def timestamp(value):
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if result.tzinfo is None or result.utcoffset() is None:
            raise ValueError("timezone missing")
        return result
    except (AttributeError, TypeError, ValueError) as error:
        raise ReviewRequired("Timestamp must contain an explicit timezone") from error


def money(value):
    if value is None:
        return None
    try:
        amount = Decimal(str(value))
        if isinstance(value, bool) or not amount.is_finite() or amount < 0:
            raise ValueError()
        if amount != amount.quantize(Decimal("0.01")) or amount >= Decimal("10000000000"):
            raise ValueError()
        return amount
    except (ValueError, InvalidOperation) as error:
        raise ReviewRequired("Invalid CHF amount (finite, nonnegative, max two decimals)") from error


def validate(record, expected_source):
    if not isinstance(record, dict):
        raise ReviewRequired("Raw record must be an object")
    for field in ("metadata", "product", "brand", "retailer_product", "price_history", "provenance", "raw_payload",
                  "gpu_details", "ram_details", "ssd_details"):
        if record.get(field) is not None and not isinstance(record[field], dict):
            raise ReviewRequired(f"{field} must be an object or null")
    meta = record.get("metadata") or {}
    if meta.get("is_example") or meta.get("is_test"):
        raise ReviewRequired("Example/test data is not eligible for production ingestion")
    if meta.get("source") != expected_source:
        raise ReviewRequired("Retailer does not match input directory")
    if expected_source not in {"digitec", "mediamarkt"}:
        raise ReviewRequired("Unsupported retailer")
    if not record.get("raw_payload"):
        raise ReviewRequired("Missing original source payload")
    if meta.get("scope_status") != "accepted":
        raise ReviewRequired("Scope is not accepted; explicit validation/reprocessing needed")
    if meta.get("quality_warnings"):
        raise ReviewRequired("Source quality warnings: " + str(meta["quality_warnings"]))
    if expected_source == "digitec" and not (record.get("provenance") or {}).get("permission_reference"):
        raise ReviewRequired("Digitec imports require a documented access/permission reference")
    if meta.get("access_method") not in {"public_html", "authorized_export", "authorized_saved_html"}:
        raise ReviewRequired("Missing or unsupported acquisition method")
    category = meta.get("category_code")
    if category not in CATEGORIES:
        raise ReviewRequired("Unknown category")
    product = record.get("product") or {}
    brand = text((record.get("brand") or {}).get("name"))
    sku = text(meta.get("source_product_id"))
    listing = record.get("retailer_product") or {}
    if not brand or not sku or not text(product.get("product_name")):
        raise ReviewRequired("Brand, source ID and product name are required")
    if text(listing.get("retailer_sku")) != sku:
        raise ReviewRequired("Source ID and listing SKU disagree")
    collected = timestamp(meta.get("collected_at"))
    kind = meta.get("observation_type", "daily_scrape")
    if kind not in {"daily_scrape", "historical_import", "master_data"}:
        raise ReviewRequired("Unknown observation type")
    prices = record.get("price_history") or {}
    price = money(prices.get("price_chf"))
    if price == 0:
        raise ReviewRequired("Zero price is not a valid component price")
    # Existing raw files encode currency in Product JSON-LD; v1 uses explicit currency.
    currency = prices.get("currency")
    if currency is None and expected_source == "mediamarkt":
        offers = record["raw_payload"].get("offers", {})
        offer = offers[0] if isinstance(offers, list) and offers else offers
        currency = offer.get("priceCurrency") if isinstance(offer, dict) else None
    if price is not None and currency != "CHF":
        raise ReviewRequired("Only explicitly denominated CHF prices are accepted")
    original = money(prices.get("original_price_chf"))
    if original is not None and price is not None and original < price:
        raise ReviewRequired("Reference price below sale price: review price semantics")
    if kind == "master_data" and price is not None:
        raise ReviewRequired("Master-only import must not carry an undated price")
    if kind == "historical_import":
        try:
            price_date = date.fromisoformat(prices["price_date"])
        except (KeyError, TypeError, ValueError) as error:
            raise ReviewRequired("Historical prices require the actual price_date") from error
        observed = timestamp(prices["observed_at"]) if prices.get("observed_at") else None
        precision = "timestamp" if observed else "day"
        if not meta.get("source_observation_id") or not meta.get("source_series_id"):
            raise ReviewRequired("Historical imports require stable source series and observation IDs")
        if prices.get("price_basis") not in {"observed_offer", "daily_min", "daily_max", "daily_close", "change_point"}:
            raise ReviewRequired("Historical price meaning must be declared")
    else:
        observed = timestamp(prices.get("observed_at") or meta["collected_at"])
        price_date = observed.astimezone(ZoneInfo("Europe/Zurich")).date()
        precision = "timestamp"
    if price_date > collected.astimezone(ZoneInfo("Europe/Zurich")).date():
        raise ReviewRequired("Price date is later than collection date")
    details = {k: (record.get(category + "_details") or {}).get(k) for k in DETAIL_FIELDS[category]}
    booleans = {"ecc", "rgb", "dram_cache"}
    integers = {"vram_gb", "clock_mhz", "boost_clock_mhz", "tdp_watts", "total_capacity_gb",
                "module_count", "capacity_per_module_gb", "speed_mts", "capacity_gb",
                "read_speed_mbps", "write_speed_mbps", "tbw"}
    for key, value in details.items():
        if value is None:
            continue
        if key in booleans and not isinstance(value, bool):
            raise ReviewRequired(f"{key}: expected boolean or null")
        if key in integers and (type(value) is not int or value <= 0):
            raise ReviewRequired(f"{key}: expected positive integer or null")
        if key == "voltage" and (money(value) is None or money(value) <= 0):
            raise ReviewRequired("Voltage must be positive")
        if key not in integers | booleans | {"voltage"} and not isinstance(value, str):
            raise ReviewRequired(f"{key}: expected string or null")
    if category == "ram" and all(details[k] is not None for k in ("total_capacity_gb", "module_count", "capacity_per_module_gb")):
        if details["total_capacity_gb"] != details["module_count"] * details["capacity_per_module_gb"]:
            raise ReviewRequired("RAM kit capacity conflict")
    return dict(source=expected_source, brand=brand, sku=sku, category=category,
                gtin=gtin(product.get("ean")), mpn=mpn_key(product.get("mpn")),
                product=product, details=details, collected=collected, observed=observed,
                price_date=price_date, precision=precision, kind=kind, price=price,
                original=original, basis=prices.get("price_basis", "observed_offer"))
