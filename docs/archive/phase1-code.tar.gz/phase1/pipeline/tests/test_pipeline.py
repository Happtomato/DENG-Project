"""Synthetic observations exist only in temporary files and isolated DB schemas."""
import copy
import json
import os
import tempfile
import unittest
import uuid
from pathlib import Path
from unittest.mock import patch

from backend.pipeline.contracts import ReviewRequired, gtin, mpn_key, validate
from backend.pipeline.db import ROOT, connect, migrate
from backend.pipeline.digitec import import_exports, map_export
from backend.pipeline.ingest import ingest_file, ingest_directory
from backend.pipeline.reprocess import reprocess_mediamarkt


def example(source='mediamarkt', sku='TEST-MM'):
    """Test-only input, never copied into data/raw or the public schema."""
    return {
        'metadata': {'source': source, 'source_product_id': sku,
                     'source_url': 'https://www.' + source + '.ch/test',
                     'collected_at': '2026-10-15T08:00:00+00:00',
                     'scope_status': 'accepted', 'category_code': 'gpu',
                     'access_method': 'public_html' if source == 'mediamarkt' else 'authorized_export',
                     'observation_type': 'daily_scrape', 'parser_version': 'isolated-test'},
        'brand': {'name': 'TEST Brand'},
        'product': {'product_name': 'TEST GPU 12GB', 'mpn': 'TEST-12-OC', 'ean': '4711387837832'},
        'retailer_product': {'retailer_sku': sku},
        'gpu_details': {'vram_gb': 12},
        'price_history': {'price_chf': 100, 'currency': 'CHF', 'price_basis': 'observed_offer'},
        'raw_payload': {'test_only': True},
        'seller': {'verified': True, 'source_id': source, 'name': source, 'is_retailer': True},
        'provenance': {'permission_reference': 'ISOLATED TEST ONLY'},
    }


class ValidationTests(unittest.TestCase):
    def test_gtin_checksum_and_leading_zero(self):
        self.assertEqual(gtin('0619659198053'), '00619659198053')
        self.assertEqual(gtin('4711387837832'), '04711387837832')
        for value in ('4711387837833', '0000000000000', 4711387837832, '123'):
            with self.assertRaises(ReviewRequired):
                gtin(value)

    def test_mpn_preserves_variant_suffixes(self):
        self.assertNotEqual(mpn_key('a-b-OC'), mpn_key('ab'))

    def test_price_and_timestamp_validation(self):
        for price in (0, -1, 'NaN', 'Infinity', True, '1.001'):
            r = example(); r['price_history']['price_chf'] = price
            with self.assertRaises(ReviewRequired): validate(r, 'mediamarkt')
        r = example(); r['metadata']['collected_at'] = '2026-10-15T08:00:00'
        with self.assertRaises(ReviewRequired): validate(r, 'mediamarkt')

    def test_null_price_allows_master_without_price_row(self):
        r=example(); r['price_history']['price_chf']=None
        self.assertIsNone(validate(r,'mediamarkt')['price'])

    def test_no_digitec_permission_no_import(self):
        r=example('digitec'); r['provenance']={}
        with self.assertRaises(ReviewRequired): validate(r,'digitec')

    def test_empty_digitec_inbox_is_explicitly_pending(self):
        with tempfile.TemporaryDirectory() as tmp:
            result=import_exports(Path(tmp)/'absent',Path(tmp)/'out')
            self.assertEqual(result['status'],'awaiting_source_data')
            self.assertFalse((Path(tmp)/'out').exists())

    def test_export_keeps_original_and_reimports_identically(self):
        item={'source_product_id':'TEST-DG', 'source_url':'https://www.digitec.ch/test',
              'category_code':'gpu', 'scope_status':'accepted', 'brand':'TEST Brand',
              'collected_at':'2026-10-15T08:00:00+00:00', 'product': example()['product'],
              'gpu_details': {'vram_gb':12}, 'observation_type':'master_data'}
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'export.json'; source.write_text(json.dumps(item))
            out=Path(tmp)/'raw'
            self.assertEqual(import_exports(source,out,'TEST ONLY')['written'],1)
            self.assertEqual(import_exports(source,out,'TEST ONLY')['existing'],1)
            raw=json.loads(next(out.glob('*.json')).read_text())
            self.assertEqual(raw['raw_payload'],item)
            self.assertEqual(raw['source_document']['content_utf8'],source.read_text())
            item['is_example']=True
            with self.assertRaises(ReviewRequired): map_export(item,'TEST',json.dumps(item))


@unittest.skipUnless(os.getenv('DENG_INTEGRATION_TESTS')=='1','Set DENG_INTEGRATION_TESTS=1 for PostgreSQL checks')
class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.conn=connect()
        self.schema='deng_test_'+uuid.uuid4().hex
        self.conn.execute('CREATE SCHEMA '+self.schema)
        self.conn.execute('SET search_path TO '+self.schema)
        migrate(self.conn)
        self.temp=tempfile.TemporaryDirectory()
        self.seq=0

    def tearDown(self):
        self.conn.execute('SET search_path TO public')
        self.conn.execute('DROP SCHEMA '+self.schema+' CASCADE')
        self.conn.close()
        self.temp.cleanup()

    def ingest(self,record):
        self.seq+=1
        path=Path(self.temp.name)/f'{self.seq}.json'; path.write_text(json.dumps(record))
        return ingest_file(self.conn,path,record['metadata']['source'])

    def count(self,table):
        return self.conn.execute('SELECT count(*) AS n FROM '+table).fetchone()['n']

    def test_migrations_and_replay_are_idempotent(self):
        migrate(self.conn)
        r=example()
        self.assertEqual(self.ingest(r),'ingested')
        self.assertEqual(self.ingest(r),'already_processed')
        self.assertEqual(self.count('product'),1)
        self.assertEqual(self.count('price_history'),1)

    def test_next_day_same_price_is_new_observation(self):
        r=example(); self.ingest(r)
        r['metadata']['collected_at']='2026-10-16T08:00:00+00:00'
        self.assertEqual(self.ingest(r),'ingested')
        self.assertEqual(self.count('price_history'),2)

    def test_digitec_enriches_same_product_and_comparison(self):
        r=example(); self.ingest(r)
        d=example('digitec','TEST-DG'); d['product']['model']='TEST model'
        d['price_history']['price_chf']=80
        self.assertEqual(self.ingest(d),'ingested')
        self.assertEqual(self.count('product'),1)
        self.assertEqual(self.count('retailer_product'),2)
        p=self.conn.execute('SELECT * FROM product').fetchone()
        self.assertEqual(p['master_status'],'digitec_validated')
        self.assertEqual(p['model'],'TEST model')
        comparison=self.conn.execute('SELECT * FROM digitec_mediamarkt_comparison').fetchone()
        self.assertEqual(comparison['difference_chf'],20)
        self.assertEqual(comparison['difference_percent'],25)

    def test_variant_conflict_rolls_back_all_entities(self):
        self.ingest(example())
        d=example('digitec','TEST-DG'); d['gpu_details']['vram_gb']=16
        self.assertEqual(self.ingest(d),'review')
        self.assertEqual(self.count('product'),1)
        self.assertEqual(self.count('retailer_product'),1)
        self.assertEqual(self.count('price_history'),1)
        self.assertEqual(self.count('matching_review'),1)

    def test_same_mpn_different_brand_does_not_merge(self):
        self.ingest(example())
        r=example('digitec','TEST-DG'); r['brand']['name']='OTHER TEST Brand'; r['product']['ean']=None
        self.assertEqual(self.ingest(r),'ingested')
        self.assertEqual(self.count('product'),2)

    def test_two_identifiers_disagree_goes_to_review(self):
        self.ingest(example())
        b=example(sku='TEST-B'); b['product'].update(mpn='TEST-B',ean='8806094215021',product_name='OTHER GPU')
        self.assertEqual(self.ingest(b),'ingested')
        d=example('digitec','TEST-DG'); d['product']['ean']='8806094215021'
        self.assertEqual(self.ingest(d),'review')
        self.assertEqual(self.count('product'),2)
        self.assertEqual(self.count('price_history'),2)

    def test_historical_dates_share_import_time_but_not_event_identity(self):
        d=example('digitec','TEST-DG')
        d['metadata'].update(observation_type='historical_import',source_series_id='TEST-SERIES',source_observation_id='2022-08-01')
        d['price_history'].update(price_date='2022-08-01',price_basis='daily_min')
        self.assertEqual(self.ingest(d),'ingested')
        d['metadata']['source_observation_id']='2023-01-01'
        d['price_history']['price_date']='2023-01-01'
        self.assertEqual(self.ingest(d),'ingested')
        self.assertEqual(self.count('price_history'),2)
        self.assertEqual(self.count('digitec_mediamarkt_comparison'),0)
        times=self.conn.execute('SELECT observed_at,time_precision FROM price_history').fetchall()
        self.assertTrue(all(r['observed_at'] is None and r['time_precision']=='day' for r in times))
        # Export repeated later must not add duplicate historical observations.
        d['metadata']['collected_at']='2026-10-16T08:00:00+00:00'
        self.assertEqual(self.ingest(d),'ingested')
        self.assertEqual(self.count('price_history'),2)

    def test_changed_price_same_event_is_review_not_overwrite(self):
        r=example(); self.ingest(r)
        r['price_history']['price_chf']=200
        self.assertEqual(self.ingest(r),'review')
        self.assertEqual(self.conn.execute('SELECT price_chf FROM price_history').fetchone()['price_chf'],100)

    def test_null_price_does_not_create_history(self):
        r=example(); r['price_history']['price_chf']=None
        self.assertEqual(self.ingest(r),'ingested')
        self.assertEqual(self.count('product'),1)
        self.assertEqual(self.count('price_history'),0)

    def test_unknown_and_marketplace_sellers_excluded_from_comparison(self):
        m=example(); m.pop('seller'); self.ingest(m)
        self.ingest(example('digitec','TEST-DG'))
        self.assertEqual(self.count('digitec_mediamarkt_comparison'),0)
        self.assertEqual(self.count('daily_price_observation'),2)

    def test_malformed_file_does_not_stop_next_file(self):
        root=Path(self.temp.name)
        (root/'1.json').write_text('{invalid')
        (root/'2.json').write_text(json.dumps(example()))
        report=ingest_directory(self.conn,root,'mediamarkt')
        self.assertEqual(report['review'],1)
        self.assertEqual(report['ingested'],1)

    def test_existing_real_media_files_only_verified_records(self):
        directory=ROOT/'data/raw/mediamarkt'
        if not directory.exists(): self.skipTest('Repository raw files not mounted')
        report=ingest_directory(self.conn,directory,'mediamarkt')
        self.assertEqual(report['error'],0)
        self.assertGreaterEqual(report['ingested'],3)
        self.assertEqual(self.count('product'),self.count('retailer_product'))
        self.assertEqual(ingest_directory(self.conn,directory,'mediamarkt')['ingested'],0)

    def test_reprocess_preserves_observation_and_repairs_missing_brand(self):
        directory=ROOT/'data/raw/mediamarkt'
        if not directory.exists(): self.skipTest('Repository evidence not mounted')
        output=Path(self.temp.name)/'reprocessed'
        result=reprocess_mediamarkt(directory,output)
        self.assertEqual(result['unresolved'],[])
        self.assertGreaterEqual(result['written'],7)
        self.assertEqual(reprocess_mediamarkt(directory,output)['written'],0)
        original=json.loads(next(directory.glob('2155505_*.json')).read_text())
        records=[json.loads(p.read_text()) for p in output.glob('*.json')]
        repaired=next(r for r in records if r['metadata']['source_product_id']=='2155505')
        self.assertEqual(repaired['metadata']['collected_at'],original['metadata']['collected_at'])
        self.assertEqual(repaired['brand']['name'],'SAMSUNG')
        self.assertEqual(ingest_directory(self.conn,output,'mediamarkt')['error'],0)
        self.assertEqual(self.count('product'),6)
        self.assertEqual(self.count('price_history'),6)

    def test_concurrent_replay_produces_one_product_and_observation(self):
        from concurrent.futures import ThreadPoolExecutor
        path=Path(self.temp.name)/'concurrent.json'; path.write_text(json.dumps(example()))
        def worker():
            with connect() as conn:
                conn.execute('SET search_path TO '+self.schema)
                return ingest_file(conn,path,'mediamarkt')
        with ThreadPoolExecutor(max_workers=2) as pool:
            results=list(pool.map(lambda _:worker(),range(2)))
        self.assertEqual(sorted(results),['already_processed','ingested'])
        self.assertEqual(self.count('product'),1)
        self.assertEqual(self.count('price_history'),1)


if __name__=='__main__':
    unittest.main()
