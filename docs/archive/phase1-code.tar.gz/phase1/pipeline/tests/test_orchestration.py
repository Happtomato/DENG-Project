import unittest
from unittest.mock import Mock, patch
from backend.orchestrator import flow as module


class IsolationTests(unittest.TestCase):
    def test_extraction_failure_still_ingests_saved_raw(self):
        with patch.object(module,'connect'), patch.object(module,'migrate'), \
             patch.object(module,'import_exports',side_effect=ValueError('TEST unavailable')), \
             patch.object(module,'ingest_retailer',return_value={'error':0}) as ingest:
            with self.assertRaises(RuntimeError):
                module.retailer_pipeline.fn('digitec')
            ingest.assert_called_once_with('digitec')

    def test_first_retailer_failure_does_not_skip_second(self):
        with patch('sys.argv',['flow']), patch.object(module,'connect'), \
             patch.object(module,'verification',return_value={}), \
             patch.object(module,'retailer_pipeline',side_effect=[RuntimeError('TEST fail'),{}]) as flow:
            self.assertEqual(module.main(),1)
            self.assertEqual([call.args[0] for call in flow.call_args_list],['digitec','mediamarkt'])
