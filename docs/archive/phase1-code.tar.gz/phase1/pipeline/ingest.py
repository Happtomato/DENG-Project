"""Transactional ingestion with conservative identity resolution and an audit queue."""
from __future__ import annotations

import hashlib
import json
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path

import psycopg
from psycopg import sql
from psycopg.types.json import Jsonb

from .contracts import (DETAIL_FIELDS, PRODUCT_FIELDS, VARIANT_FIELDS, ReviewRequired,
                        digest, money, normalized, text, validate)

RETAILERS = {"digitec": ("Digitec", "https://www.digitec.ch"),
             "mediamarkt": ("MediaMarkt", "https://www.mediamarkt.ch")}


def entity(conn, table, name, **extra):
    key = table + "_id"
    if table == "brand":
        row = conn.execute("SELECT brand_id FROM brand WHERE lower(btrim(name)) = lower(btrim(%s))", (name,)).fetchone()
        if row:
            return row[key]
    columns = ["name", *extra]
    query = sql.SQL("INSERT INTO {} ({}) VALUES ({}) ON CONFLICT(name) DO UPDATE SET name=EXCLUDED.name RETURNING {}").format(
        sql.Identifier(table), sql.SQL(",").join(map(sql.Identifier, columns)),
        sql.SQL(",").join(sql.Placeholder() for _ in columns), sql.Identifier(key))
    return conn.execute(query, [name, *extra.values()]).fetchone()[key]


def compatible(conn, product, incoming):
    if product["brand_id"] != incoming["brand_id"] or product["category_id"] != incoming["category_id"]:
        raise ReviewRequired("Identifier matches but manufacturer/category conflicts")
    if incoming["mpn"] and product["mpn_normalized"] and incoming["mpn"] != product["mpn_normalized"]:
        raise ReviewRequired("GTIN/listing matches but manufacturer part number conflicts")
    details = conn.execute(sql.SQL("SELECT * FROM {} WHERE product_id=%s").format(
        sql.Identifier(incoming["category"] + "_details")), (product["product_id"],)).fetchone() or {}
    for field in VARIANT_FIELDS[incoming["category"]]:
        old, new = details.get(field), incoming["details"].get(field)
        if old is not None and new is not None and normalized(old) != normalized(new):
            raise ReviewRequired(f"Variant conflict: {field}")


def resolve_product(conn, v):
    matches = set()
    method = None
    if v["mpn"]:
        rows = conn.execute("SELECT product_id FROM product WHERE brand_id=%s AND mpn_normalized=%s",
                            (v["brand_id"], v["mpn"])).fetchall()
        matches.update(r["product_id"] for r in rows)
        if rows:
            method = "manufacturer_mpn"
    if v["gtin"]:
        rows = conn.execute("""SELECT product_id FROM product_gtin WHERE gtin14=%s
            UNION SELECT product_id FROM product WHERE lpad(ean,14,'0')=%s""", (v["gtin"], v["gtin"])).fetchall()
        matches.update(r["product_id"] for r in rows)
        if rows and method is None:
            method = "gtin"
    listing = conn.execute("SELECT product_id FROM retailer_product WHERE retailer_id=%s AND retailer_sku=%s",
                           (v["retailer_id"], v["sku"])).fetchone()
    if listing:
        matches.add(listing["product_id"])
        method = method or "existing_listing"
    if len(matches) > 1:
        raise ReviewRequired("MPN, GTIN or existing listing point to different products")
    if matches:
        product = conn.execute("SELECT * FROM product WHERE product_id=%s", (matches.pop(),)).fetchone()
        compatible(conn, product, v)
        return product, method
    # Similar names are review candidates only. Do not create a second product
    # with the same normalized title when identifiers do not resolve it.
    if conn.execute("SELECT 1 FROM product WHERE brand_id=%s AND lower(btrim(product_name))=lower(btrim(%s))",
                    (v["brand_id"], v["product"]["product_name"])).fetchone():
        raise ReviewRequired("Same-name candidate requires manual identity review")
    if not v["gtin"] and not v["mpn"]:
        raise ReviewRequired("No validated identifier; name-only automatic creation is disabled")
    row = conn.execute("""INSERT INTO product (brand_id,category_id,product_name,mpn_normalized)
        VALUES (%s,%s,%s,%s) RETURNING *""",
        (v["brand_id"], v["category_id"], v["product"]["product_name"], v["mpn"])).fetchone()
    return row, "new_validated_identifier"


def set_attribute(conn, product_id, table, field, value, raw_id):
    conn.execute(sql.SQL("UPDATE {} SET {}=%s WHERE product_id=%s").format(sql.Identifier(table), sql.Identifier(field)),
                 (value, product_id))
    conn.execute("""INSERT INTO product_attribute_source(product_id,attribute,value,raw_record_id)
        VALUES (%s,%s,%s,%s) ON CONFLICT(product_id,attribute) DO UPDATE
        SET value=EXCLUDED.value, raw_record_id=EXCLUDED.raw_record_id""",
        (product_id, table + "." + field, Jsonb(str(value) if isinstance(value, Decimal) else value), raw_id))


def enrich(conn, product, v, raw_id):
    pid = product["product_id"]
    # Digitec is preferred, but no source may bypass compatible() conflict checks.
    prefer = v["source"] == "digitec" and v["kind"] != "historical_import"
    for field in PRODUCT_FIELDS:
        value = v["product"].get(field)
        if value is None or value == "":
            continue
        if field == "msrp_chf":
            value = money(value)
        if product.get(field) is None or product["master_source"] is None or (prefer and product["master_source"] != "digitec"):
            set_attribute(conn, pid, "product", field, value, raw_id)
    table = v["category"] + "_details"
    if any(value is not None for value in v["details"].values()):
        conn.execute(sql.SQL("INSERT INTO {}(product_id) VALUES (%s) ON CONFLICT(product_id) DO NOTHING").format(sql.Identifier(table)), (pid,))
        existing = conn.execute(sql.SQL("SELECT * FROM {} WHERE product_id=%s").format(sql.Identifier(table)), (pid,)).fetchone()
        for field, value in v["details"].items():
            if value is not None and (existing[field] is None or (prefer and product["master_source"] != "digitec")):
                set_attribute(conn, pid, table, field, value, raw_id)
    if v["gtin"]:
        conn.execute("INSERT INTO product_gtin(gtin14,product_id,raw_record_id) VALUES (%s,%s,%s) ON CONFLICT(gtin14) DO NOTHING",
                     (v["gtin"], pid, raw_id))
    conn.execute("""UPDATE product SET mpn_normalized=COALESCE(mpn_normalized,%s),
        master_source=CASE WHEN %s THEN 'digitec' ELSE COALESCE(master_source,%s) END,
        master_status=CASE WHEN %s THEN 'digitec_validated' ELSE master_status END,
        updated_at=CURRENT_TIMESTAMP WHERE product_id=%s""",
        (v["mpn"], prefer, v["source"], prefer, pid))


def seller(record):
    explicit = record.get("seller")
    if isinstance(explicit, dict) and explicit.get("verified") is True and explicit.get("name"):
        return (str(explicit.get("source_id") or normalized(explicit["name"])), explicit["name"],
                explicit.get("is_retailer") if isinstance(explicit.get("is_retailer"), bool) else None)
    offers = (record.get("raw_payload") or {}).get("offers", {})
    offer = offers[0] if isinstance(offers, list) and offers else offers
    value = offer.get("seller") if isinstance(offer, dict) else None
    if isinstance(value, dict) and value.get("name"):
        name = value["name"]
        # Only the explicitly named legal retailer can count as own-retailer.
        own_names = {"mediamarkt": {"mediamarkt", "mediamarkt schweiz"},
                     "digitec": {"digitec", "digitec galaxus ag"}}
        own = normalized(name) in own_names[record["metadata"]["source"]]
        return str(value.get("id") or normalized(name)), name, own
    return "unknown", None, None


def ingest_valid(conn, record, v, raw_id):
    v["brand_id"] = entity(conn, "brand", v["brand"])
    v["category_id"] = entity(conn, "category", v["category"].upper())
    name, website = RETAILERS[v["source"]]
    v["retailer_id"] = entity(conn, "retailer", name, website=website)
    product, method = resolve_product(conn, v)
    enrich(conn, product, v, raw_id)
    listing = conn.execute("""INSERT INTO retailer_product
        (product_id,retailer_id,retailer_sku,retailer_product_name,product_url,first_seen_at,last_seen_at,
         match_method,matched_raw_record_id)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
        ON CONFLICT(retailer_id,retailer_sku) DO UPDATE SET
          retailer_product_name=EXCLUDED.retailer_product_name, product_url=EXCLUDED.product_url,
          first_seen_at=LEAST(retailer_product.first_seen_at,EXCLUDED.first_seen_at),
          last_seen_at=GREATEST(retailer_product.last_seen_at,EXCLUDED.last_seen_at)
        RETURNING retailer_product_id""",
        (product["product_id"], v["retailer_id"], v["sku"], v["product"]["product_name"],
         record["metadata"].get("source_url"), v["collected"], v["collected"], method, raw_id)).fetchone()
    if v["price"] is None or v["kind"] == "master_data":
        return "master_without_price"
    meta = record["metadata"]
    seller_key, seller_name, seller_is_retailer = seller(record)
    if v["kind"] == "historical_import":
        event = [meta.get("provider", v["source"]), meta["source_series_id"], meta["source_observation_id"]]
    else:
        event = meta.get("observation_id") or v["observed"].isoformat()
    key = digest([v["source"], v["sku"], seller_key, v["kind"], event])
    previous = conn.execute("SELECT * FROM price_history WHERE observation_key=%s", (key,)).fetchone()
    if previous:
        if (previous["price_chf"] != v["price"] or previous["price_date"] != v["price_date"]
                or previous["price_basis"] != v["basis"]):
            raise ReviewRequired("Existing observation changed: correction requires explicit review")
        return "duplicate_observation"
    discount = None
    if v["original"] and v["original"] >= v["price"]:
        discount = ((v["original"] - v["price"]) / v["original"] * 100).quantize(Decimal(".01"), rounding=ROUND_HALF_UP)
    conn.execute("""INSERT INTO price_history
        (retailer_product_id,price_chf,original_price_chf,discount_percent,availability,collected_at,
         observation_key,observation_type,observed_at,price_date,time_precision,price_basis,currency,
         raw_record_id,seller_key,seller_name,seller_is_retailer,original_price_type)
        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'CHF',%s,%s,%s,%s,%s)""",
        (listing["retailer_product_id"], v["price"], v["original"], discount,
         record["price_history"].get("availability"), v["collected"], key, v["kind"],
         v["observed"], v["price_date"], v["precision"], v["basis"], raw_id,
         seller_key, seller_name, seller_is_retailer,
         record["price_history"].get("original_price_type", "retailer_reference" if v["original"] is not None else None)))
    return "price_inserted"


def ingest_file(conn, path, source):
    content = path.read_bytes()
    sha = hashlib.sha256(content).hexdigest()
    try:
        record = json.loads(content)
        if not isinstance(record, dict):
            raise ValueError("Raw JSON must be an object")
    except (ValueError, UnicodeError) as error:
        record = {}
        parse_error = str(error)
    else:
        parse_error = None
    meta = record.get("metadata") or {}
    if not isinstance(meta, dict):
        meta = {}
    with conn.transaction():
        # Serializes small batch identity decisions across retailer processes.
        # Database constraints are still the final uniqueness boundary.
        conn.execute("SELECT pg_advisory_xact_lock(91342002)")
        row = conn.execute("""INSERT INTO raw_record(sha256,retailer_code,path,source_url,parser_version,provenance)
            VALUES (%s,%s,%s,%s,%s,%s) ON CONFLICT(sha256) DO UPDATE SET path=EXCLUDED.path RETURNING *""",
            (sha, source, str(path), meta.get("source_url"), meta.get("parser_version", "legacy_unversioned"),
             Jsonb(record.get("provenance") or {}))).fetchone()
        rid = row["raw_record_id"]
        if row["retailer_code"] != source:
            raise ReviewRequired("Same file submitted under another retailer")
        if row["status"] in {"ingested", "excluded"}:
            return "already_processed"
        status, reason = "ingested", None
        try:
            with conn.transaction():
                if parse_error:
                    raise ReviewRequired(parse_error)
                v = validate(record, source)
                conn.execute("UPDATE raw_record SET collected_at=%s WHERE raw_record_id=%s", (v["collected"], rid))
                reason = ingest_valid(conn, record, v, rid)
                conn.execute("DELETE FROM matching_review WHERE raw_record_id=%s", (rid,))
        except (ReviewRequired, KeyError, TypeError, ValueError) as error:
            status, reason = "review", str(error)
            if meta.get("scope_status") == "excluded":
                status = "excluded"
            if status == "review":
                # Only suggestions, never an automatic fuzzy merge.
                candidate_product = record.get("product")
                name = text(candidate_product.get("product_name")) if isinstance(candidate_product, dict) else None
                candidates = []
                if name:
                    candidates = [r["product_id"] for r in conn.execute(
                        "SELECT product_id FROM product WHERE lower(product_name) LIKE %s LIMIT 10",
                        ("%" + name.split()[0].lower().replace("%", "").replace("_", "") + "%",)).fetchall()]
                conn.execute("""INSERT INTO matching_review(raw_record_id,reason,candidate_product_ids)
                    VALUES (%s,%s,%s) ON CONFLICT(raw_record_id) DO UPDATE
                    SET reason=EXCLUDED.reason,candidate_product_ids=EXCLUDED.candidate_product_ids""", (rid, reason, candidates))
        except psycopg.Error as error:
            status, reason = "error", str(error).splitlines()[0]
        conn.execute("UPDATE raw_record SET status=%s,reason=%s,processed_at=CURRENT_TIMESTAMP WHERE raw_record_id=%s", (status, reason, rid))
        return status


def ingest_directory(conn, directory, source):
    report = {"source": source, "files": 0, "ingested": 0, "review": 0, "excluded": 0,
              "error": 0, "already_processed": 0}
    for path in sorted(Path(directory).rglob("*.json")):
        report["files"] += 1
        try:
            status = ingest_file(conn, path, source)
        except (OSError, ValueError, psycopg.Error):
            status = "error"
        report[status] += 1
    report["source_status"] = "awaiting_source_data" if report["files"] == 0 else "processed"
    return report
