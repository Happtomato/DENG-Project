# Inaktiver Phase-1-Stand

Vor der freigegebenen Vereinfachung erhaltene Pipeline inklusive der damaligen 23 Tests. Kein aktiver Importpfad, keine aktuelle Test-Suite. Die alten relativen Projektpfade gelten hier nicht mehr. Digitec-Adapter und Mastering sind erst nach dem Midterm wieder zu bewerten. Wiederherstellung des vollständigen Ausgangsstands liegt zusätzlich im Chat-Arbeitsordner als phase2-before.tar.gz.
